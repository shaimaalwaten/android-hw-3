package com.example.supercv;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;

public class Contact extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        final TextView b = findViewById(R.id.textView6);
        ImageView ae = findViewById(R.id.imageView3);
        ae.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("http://instagram.com/_u/ssja7_");
                Intent instagram = new Intent(Intent.ACTION_VIEW, uri);
                instagram.setPackage("com.instagram.android");
                try {
                    startActivity(instagram);
                } catch (ActivityNotFoundException e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/ssja7_")));
                }
            }
        });
    }

    public void onDialButton (View v) {
        Intent intenr = new Intent(Intent.ACTION_CALL);
        intenr.setData(Uri.parse("tel:99688685"));
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED){
            return;
        }
        startActivity(intenr);
    }
    public void yas (View view) {
        try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setData(Uri.parse("mailto"));

                send.setType("message/rfo822");
                send.putExtra(Intent.EXTRA_EMAIL, "shaimaalw2@gmail.com");
                send.putExtra(Intent.EXTRA_SUBJECT, "Title");
                send.putExtra(Intent.EXTRA_TEXT, "subject");
                startActivity(send);
            } catch (Exception e){Toast.makeText(this, "Failed,", Toast.LENGTH_LONG).show(); }

        }
    }